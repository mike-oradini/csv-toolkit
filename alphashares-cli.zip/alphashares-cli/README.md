# AlphaShares CLI Toolset

Automate CSV and Web3 tasks via CLI.

